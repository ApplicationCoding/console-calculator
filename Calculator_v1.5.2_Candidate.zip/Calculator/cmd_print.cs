﻿// This file is still being developed

using System;

namespace Calculator
{
    class Command_Print
    {
        static void Print(string[] args)
        {
            // Ask the user
            Console.WriteLine("Do you want to Calculator to print all available commands for this app?");

            string ShowCommandsConfirmation = Console.ReadLine();

            // This will print the available commands if the user typed 'Yes' or 'yes'
            if (ShowCommandsConfirmation == "Yes")
            {
                Console.WriteLine("about = Shows the current version of this app;");
                Console.WriteLine("help (current command) = Shows you all available commands for this calculator console.");
                Console.WriteLine("extra msg = Lets you read more message by this app.");
                Console.WriteLine("re-calculate = Allows you to re-calculate again without re-opening the app.");
                Console.WriteLine("exit = Closes this app.");
            }

            if (ShowCommandsConfirmation == "yes")
            {
                Console.WriteLine("about = Shows the current version of this app;");
                Console.WriteLine("help (current command) = Shows you all available commands for this calculator console.");
                Console.WriteLine("extra msg = Lets you read more message by this app.");
                Console.WriteLine("re-calculate = Allows you to re-calculate again without re-opening the app.");
                Console.WriteLine("exit = Closes this app.");
            }

            // This will close the app if the user typed 'No' or 'no'
            if (ShowCommandsConfirmation == "No")
            {
                Console.WriteLine("Closing the app...");
                Environment.Exit(6);
            }

            if (ShowCommandsConfirmation == "no")
            {
                Console.WriteLine("Closing the app...");
                Environment.Exit(6);
            }
        }
    }
}