﻿using System;

namespace Calculator
{
    class Command_Print
    {
        static void Print(string[] args)
        {
            Console.WriteLine("Do you want to Calculator to print all available commands for this app?");

            string ShowCommandsConfirmation = Console.ReadLine();

            if (ShowCommandsConfirmation == "Yes")
            {
                Console.WriteLine("about = Shows the current version of this app;");
                Console.WriteLine("help (current command) = Shows you all available commands for this calculator console.");
                Console.WriteLine("extra msg = Lets you read more message by this app.");
                Console.WriteLine("re-calculate = Allows you to re-calculate again without re-opening the app.");
                Console.WriteLine("exit = Closes this app.");
            }

            if (ShowCommandsConfirmation == "yes")
            {
                Console.WriteLine("about = Shows the current version of this app;");
                Console.WriteLine("help (current command) = Shows you all available commands for this calculator console.");
                Console.WriteLine("extra msg = Lets you read more message by this app.");
                Console.WriteLine("re-calculate = Allows you to re-calculate again without re-opening the app.");
                Console.WriteLine("exit = Closes this app.");
            }

            if (ShowCommandsConfirmation == "No")
            {
                Environment.Exit(2);
            }

            if (ShowCommandsConfirmation == "no")
            {
                Environment.Exit(2);
            }
        }
    }
}