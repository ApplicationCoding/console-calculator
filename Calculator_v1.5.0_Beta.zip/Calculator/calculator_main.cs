﻿using System;

namespace Calculator
{
    class calculator_main
    {
        static void Main(string[] args)
        {
            // Welcome the user to Calculator
            Console.WriteLine("Welcome to Calculator!");
            Console.WriteLine("Please enter your intended math operation: ");

            // Lets the user enter his/her intended math operation
            string enterMathOperation = Console.ReadLine();

            Console.WriteLine("Enter your first numbers: ");
            // User should enter numbers
            int enterFirstNumbers = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter your second numbers: ");
            int enterSecondNumbers = Convert.ToInt32(Console.ReadLine());

            // Addition operation
            if (enterMathOperation == "Addition")
            {
                // This will add and print the entered number of the user
                Console.Write("The sum is: ");
                Console.WriteLine(enterFirstNumbers + enterSecondNumbers);
            }

            else if (enterMathOperation == "addition")
            {
                Console.Write("The sum is: ");
                Console.WriteLine(enterFirstNumbers + enterSecondNumbers);
            }

            else if (enterMathOperation == "Add")
            {
                Console.Write("The sum is: ");
                Console.WriteLine(enterFirstNumbers + enterSecondNumbers);
            }

            else if (enterMathOperation == "add")
            {
                Console.Write("The sum is: ");
                Console.WriteLine(enterFirstNumbers + enterSecondNumbers);
            }

            // Subtraction operation
            else if (enterMathOperation == "Subtraction")
            {
                // Subtract the entered numbers by user
                Console.Write("The difference is: ");
                Console.WriteLine(enterFirstNumbers - enterSecondNumbers);
            }

            else if (enterMathOperation == "subtraction")
            {
                Console.Write("The difference is: ");
                Console.WriteLine(enterFirstNumbers - enterSecondNumbers);
            }

            else if (enterMathOperation == "Subtract")
            {
                Console.Write("The difference is: ");
                Console.WriteLine(enterFirstNumbers - enterSecondNumbers);
            }

            else if (enterMathOperation == "subtract")
            {
                Console.Write("The difference is: ");
                Console.WriteLine(enterFirstNumbers - enterSecondNumbers);
            }

            // Multiplication operation
            else if (enterMathOperation == "Multiplication")
            {
                // Multiplies the entered numbers by user
                Console.Write("The product is: ");
                Console.WriteLine(enterFirstNumbers * enterSecondNumbers);
            }

            else if (enterMathOperation == "multiplication")
            {
                Console.Write("The product is: ");
                Console.WriteLine(enterFirstNumbers * enterSecondNumbers);
            }

            else if (enterMathOperation == "Multiply")
            {
                Console.Write("The product is: ");
                Console.WriteLine(enterFirstNumbers * enterSecondNumbers);
            }

            else if (enterMathOperation == "multiply")
            {
                Console.Write("The product is: ");
                Console.WriteLine(enterFirstNumbers * enterSecondNumbers);
            }

            // Division operation
            else if (enterMathOperation == "Division")
            {
                // Divides the entered numbers by the user
                Console.Write("The quiotient is: ");
                Console.WriteLine(enterFirstNumbers / enterSecondNumbers);
            }

            else if (enterMathOperation == "division")
            {
                Console.Write("The quiotient is: ");
                Console.WriteLine(enterFirstNumbers / enterSecondNumbers);
            }

            else if (enterMathOperation == "Divide")
            {
                Console.Write("The quiotient is: ");
                Console.WriteLine(enterFirstNumbers / enterSecondNumbers);
            }

            else if (enterMathOperation == "divide")
            {
                Console.Write("The quiotient is: ");
                Console.WriteLine(enterFirstNumbers / enterSecondNumbers);
            }

            // This will prevent the console from automatically closing after the user has entered the second numbers
            Console.WriteLine("Please type 'help' if you'd like to continue; 'about' if you'd like to see the version of this app; 're-calculate' if you'd want to read the extra message of this app; or simply type 'close' or click the X button to close this window...");

            string endOptions = Console.ReadLine();

            if (endOptions == "help")
            {
                Console.WriteLine("about = Shows the current version of this app;");
                Console.WriteLine("help (current command) = Shows you all available commands for this calculator console.");
                Console.WriteLine("extra msg = Lets you read more message by this app.");
                Console.WriteLine("re-calculate = Allows you to re-calculate again without re-opening the app.");
                Console.WriteLine("exit = Closes this app.");
            }

            else if (endOptions == "about")
            {
                Console.WriteLine("Current Version: Calculator v1.5.0 Beta");
            }

            else if (endOptions == "re-calculate")
            {
                Console.WriteLine("Welcome to Calculator!");

                // Lets the user know that the user selected to re-calculate.
                Console.WriteLine("As you've selected, you will re-calculate.");
                Console.WriteLine("Please enter your intended math operation: ");

                // Lets the user enter his/her intended math operation
                string enterMathOperationSecond = Console.ReadLine();

                Console.WriteLine("Enter your first numbers: ");
                // User should enter numbers
                int enterFirstNumbersSecondCalc = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter your second numbers: ");
                int enterSecondNumbersSecondCalc = Convert.ToInt32(Console.ReadLine());

                // Addition operation
                if (enterMathOperation == "Addition")
                {
                    // This will add and print the entered number of the user
                    Console.Write("The sum is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc + enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "addition")
                {
                    Console.Write("The sum is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc + enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "Add")
                {
                    Console.Write("The sum is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc + enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "add")
                {
                    Console.Write("The sum is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc + enterSecondNumbersSecondCalc);
                }

                // Subtraction operation
                else if (enterMathOperation == "Subtraction")
                {
                    // Subtract the entered numbers by user
                    Console.Write("The difference is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc - enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "subtraction")
                {
                    Console.Write("The difference is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc - enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "Subtract")
                {
                    Console.Write("The difference is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc - enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "subtract")
                {
                    Console.Write("The difference is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc - enterSecondNumbersSecondCalc);
                }

                // Multiplication operation
                else if (enterMathOperation == "Multiplication")
                {
                    // Multiplies the entered numbers by user
                    Console.Write("The product is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc * enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "multiplication")
                {
                    Console.Write("The product is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc * enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "Multiply")
                {
                    Console.Write("The product is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc * enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "multiply")
                {
                    Console.Write("The product is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc * enterSecondNumbersSecondCalc);
                }

                // Division operation
                else if (enterMathOperation == "Division")
                {
                    // Divides the entered numbers by the user
                    Console.Write("The quiotient is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc / enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "division")
                {
                    Console.Write("The quiotient is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc / enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "Divide")
                {
                    Console.Write("The quiotient is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc / enterSecondNumbersSecondCalc);
                }

                else if (enterMathOperation == "divide")
                {
                    Console.Write("The quiotient is: ");
                    Console.WriteLine(enterFirstNumbersSecondCalc / enterSecondNumbersSecondCalc);
                }

                // This will prevent the console from automatically closing after the user has entered the second numbers
                Console.WriteLine("Please type 'help' if you'd like to continue; 'about' if you'd like to see the version of this app; 're-calculate' if you'd want to read the extra message of this app; or simply type 'close' or click the X button to close this window...");

                string SecondEndOptions = Console.ReadLine();

                if (SecondEndOptions == "help")
                {
                    Console.WriteLine("about = Shows the current version of this app;");
                    Console.WriteLine("help (current command) = Shows you all available commands for this calculator console.");
                    Console.WriteLine("extra msg = Lets you read more message by this app.");
                    Console.WriteLine("re-calculate = Allows you to re-calculate again without re-opening the app.");
                    Console.WriteLine("exit = Closes this app.");
                }

                else if (SecondEndOptions == "about")
                {
                    Console.WriteLine("Current Version: Calculator v1.5.0 Beta");
                }

                else if (SecondEndOptions == "re-calculate")
                {

                }

                // If the user types 'close', the app will also close
                else if (SecondEndOptions == "close")
                {
                    Console.WriteLine("Closing...");

                    // Environment.Exit(5) will close the app
                    Environment.Exit(5);
                }

                // This prevents the app from automatically closing
                Console.ReadKey();
            }

            // If the user types 'close', the app will also close
            else if (endOptions == "close")
            {
                Console.WriteLine("Closing...");
                
                // Environment.Exit(5) will close the app
                Environment.Exit(5);
            }

            // This prevents the app from automatically closing
            Console.ReadKey();
        }
    }
}